import rospy
from std_msgs.msg import String

def callback(message):
       rospy.loginfo(f"REcieved:{message.data}")
        
def sub():
       rospy.init_node('subscriber_node', anonymous=True)
   
       rospy.Subscriber("/chat", String, callback)
       rospy.spin()
   
if __name__ == '__main__':
    try: 
        sub() 
    except rospy.ROSInterruptException: 
        pass
    

