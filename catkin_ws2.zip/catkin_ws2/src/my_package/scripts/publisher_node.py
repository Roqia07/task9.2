import rospy
from std_msgs.msg import String

def pub_node():
	pub=rospy.Publisher('/chat',String,queue_size=10)
	rospy.init_node('publisher_node')
	rate=rospy.Rate(1)
	while not rospy.is_shutdown():
		messages='HelloWorld'
		rospy.loginfo("publish")
		pub.publish(messages)
		rate.sleep()
            
if __name__ == '__main__':
    try: 
        pub_node() 
    except rospy.ROSInterruptException: 
        pass